function [x,u]=pvc(a,b,n,tipo_a,ua,sigma_a,alfa_a,beta_a,gamma_a,tipo_b,ub,sigma_b,alfa_b,beta_b,gamma_b);

% define variaveis principais
h = (b-a)/(n-1);
x = linspace(a,b,n);
x = x';
f = zeros(n,1);
u = zeros(n,1);
A = zeros(n,n);

% considera valores especificos para as funcoes p, q e r
[p,q,r]=funcoes(a,b,n);

% monta sistema Au=f
A(1,1) = ...;
A(1,2) = ...;
f(1)   = ...;
for i = 2:n-1
    A(i,i-1) = ...;
    A(i,i)   = ...;
    A(i,i+1) = ...;
    f(i)     = ...;
endfor
A(n,n-1) = ...;
A(n,n)   = ...;  
f(n)     =  ...;

% aplica condicoes de contorno em x=a;
b1 = ...;
switch tipo_a
case 1 
     ...;
case 2
       ...;
case 3
       ...;
otherwise
       printf("Erro na Condicao de contorno"); 
end

% aplica condicoes de contorno em x=b;
cn = ...;
switch tipo_b
case 1
   ...;
case 2 
    ...;
case 3
    ...; 
otherwise
       printf("Erro na Condicao de contorno"); 
end 

% Resolve sistema linear
u = A\f;
      
endfunction       
       
